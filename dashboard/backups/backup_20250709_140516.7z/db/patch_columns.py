import sqlite3

conn = sqlite3.connect("dashboard/db/task_logs.db")
cursor = conn.cursor()

# ✅ Add confidence column (if missing)
try:
    cursor.execute("ALTER TABLE logs ADD COLUMN confidence REAL")
    print("✅ Added 'confidence' column")
except sqlite3.OperationalError:
    print("ℹ️ 'confidence' column already exists")

# ✅ Add final_result column (if missing)
try:
    cursor.execute("ALTER TABLE logs ADD COLUMN final_result TEXT")
    print("✅ Added 'final_result' column")
except sqlite3.OperationalError:
    print("ℹ️ 'final_result' column already exists")

conn.commit()
conn.close()
