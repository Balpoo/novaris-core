# dashboard/db/migrate.py

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "task_logs.db")

def run_migrations():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Check if table already exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='logs'")
        exists = cursor.fetchone()

        if not exists:
            print("📦 Creating table: logs")
            cursor.execute("""
                CREATE TABLE logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    task TEXT,
                    agent TEXT,
                    confidence REAL,
                    final_result TEXT
                )
            """)
            print("✅ Logs table created successfully.")
        else:
            print("ℹ️ Logs table already exists.")

        conn.commit()
        conn.close()

    except Exception as e:
        print(f"❌ Migration failed: {e}")
