# dashboard/db/migrate.py

import sqlite3
import os

REQUIRED_COLUMNS = {
    "confidence": "REAL",
    "final_result": "TEXT"
}

def get_existing_columns(cursor, table_name="logs"):
    cursor.execute(f"PRAGMA table_info({table_name})")
    return [row[1] for row in cursor.fetchall()]

def run_migrations():
    db_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "task_logs.db"))
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        existing_columns = get_existing_columns(cursor)

        for column_name, column_type in REQUIRED_COLUMNS.items():
            if column_name not in existing_columns:
                cursor.execute(f"ALTER TABLE logs ADD COLUMN {column_name} {column_type}")
                print(f"✅ Added column: {column_name} ({column_type})")
            else:
                print(f"ℹ️ Column already exists: {column_name}")

        conn.commit()
        print("✅ Migration completed successfully.")

    except Exception as e:
        print("❌ Migration failed:", str(e))

    finally:
        conn.close()

if __name__ == "__main__":
    run_migrations()
